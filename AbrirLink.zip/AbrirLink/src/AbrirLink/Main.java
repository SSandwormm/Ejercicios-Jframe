package AbrirLink;

public class Main {

    public static void main(String[] args) {
        Abrir abrir = new Abrir();
        abrir.setVisible(true);
    }
}
