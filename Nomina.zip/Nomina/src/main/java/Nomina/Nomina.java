package Nomina;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Nomina extends javax.swing.JFrame {

    int precio = 4833;
    int HoraExtra = 6042;

    int horasExtra, sueldoExtra, sueldo, horas, total;

    DefaultTableModel Modelo = new DefaultTableModel();
    DefaultTableModel Modelo2 = new DefaultTableModel();
    ArrayList<EmpleadosPago> Personal = new ArrayList<EmpleadosPago>();
    ArrayList<EmpleadosPago> Personall = new ArrayList<EmpleadosPago>();

    public Nomina() {
        initComponents();
        this.setLocationRelativeTo(null);

        Modelo.addColumn("Id");
        Modelo.addColumn("Nombre");
        Modelo.addColumn("Apellido");
        Modelo.addColumn("Telefono");
        Modelo.addColumn("Horas");
        Modelo.addColumn("Horas Extras");
        refrescarTabla();

        Modelo2.addColumn("Id");
        Modelo2.addColumn("Nombre");
        Modelo2.addColumn("Apellido");
        Modelo2.addColumn("Pago Hora");
        Modelo2.addColumn("Pago Extras");
        Modelo2.addColumn("Pago Total");
        tablaFinal();
    }

    public void refrescarTabla() {
        while (Modelo.getRowCount() > 0) {
            Modelo.removeRow(0);
        }
        for (EmpleadosPago Datos : Personal) {
            Object a[] = new Object[6];
            a[0] = Datos.getId();
            a[1] = Datos.getNombre();
            a[2] = Datos.getApellido();
            a[3] = Datos.getTelefono();
            a[4] = Datos.getNumeroHoras();
            a[5] = Datos.getNumeroHorasExtras();
            Modelo.addRow(a);
        }
        tblTablaEm.setModel(Modelo);
    }

    public void tablaFinal() {
        while (Modelo2.getRowCount() > 0) {
            Modelo2.removeRow(0);
        }
        for (EmpleadosPago Datos2 : Personall) {
            Object a[] = new Object[6];
            a[0] = Datos2.getId();
            a[1] = Datos2.getNombre();
            a[2] = Datos2.getApellido();
            a[3] = Datos2.getPagoHoras();
            a[4] = Datos2.getPagoHorasExtras();
            a[5] = Datos2.getTotalPago();
            Modelo2.addRow(a);
        }
        tblFinal.setModel(Modelo2);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtHoras = new javax.swing.JTextField();
        txtHorasEX = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTablaEm = new javax.swing.JTable();
        btnAgregar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblFinal = new javax.swing.JTable();
        btnBorrar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        Total = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        SueldoExtras = new javax.swing.JLabel();
        SuledoNormal = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnRefrescar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Unispace", 3, 48)); // NOI18N
        jLabel1.setText("Nomina");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 310, 60));

        jLabel2.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jLabel2.setText("Id");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 120, 30));

        jLabel3.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jLabel3.setText("Nombre");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, 120, 30));

        jLabel4.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jLabel4.setText("Apellido");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 100, 120, 30));

        jLabel5.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jLabel5.setText("Horas");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 100, 120, 30));

        jLabel6.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jLabel6.setText("Telefono");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 100, 120, 30));

        jLabel7.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jLabel7.setText("HorasExtras");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 100, 120, 30));

        txtId.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        jPanel1.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 130, 120, 30));

        txtNombre.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, 120, 30));

        txtApellido.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jPanel1.add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 130, 120, 30));

        txtTelefono.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jPanel1.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 130, 120, 30));

        txtHoras.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jPanel1.add(txtHoras, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 130, 120, 30));

        txtHorasEX.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        txtHorasEX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHorasEXActionPerformed(evt);
            }
        });
        jPanel1.add(txtHorasEX, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 130, 120, 30));

        tblTablaEm.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        tblTablaEm.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tblTablaEm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTablaEmMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblTablaEm);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 970, 160));

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        jPanel1.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 180, 90, 40));

        tblFinal.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        jScrollPane2.setViewportView(tblFinal);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 410, 610, 210));

        btnBorrar.setText("Borrar");
        btnBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarActionPerformed(evt);
            }
        });
        jPanel1.add(btnBorrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 180, 80, 40));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Pago :"));

        Total.setText("0.00$");

        jLabel8.setText("Pago Total :");

        jLabel10.setText("Pago Horas Extras :");

        SueldoExtras.setText("0.00$");

        SuledoNormal.setText("0.00$");

        jLabel9.setText("Pago Horas :");

        btnRefrescar.setText("Total a Pagar :");
        btnRefrescar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefrescarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Total, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SuledoNormal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SueldoExtras, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(btnRefrescar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SuledoNormal, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SueldoExtras, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRefrescar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 405, 340, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 880, 20));

        Fondo.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 650));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed

    }//GEN-LAST:event_txtIdActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        try {
            EmpleadosPago objeto = new EmpleadosPago();
            objeto.setId(Integer.parseInt(txtId.getText()));
            objeto.setNombre(txtNombre.getText());
            objeto.setApellido(txtApellido.getText());
            objeto.setTelefono(txtTelefono.getText());
            objeto.setNumeroHoras(Integer.parseInt(txtHoras.getText()));
            objeto.setNumeroHorasExtras(Integer.parseInt(txtHorasEX.getText()));
            Personal.add(objeto);
            JOptionPane.showMessageDialog(null, "Empleado agregado");

            refrescarTabla();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "ERROR");
        }

    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarActionPerformed
        Limpiar();
    }//GEN-LAST:event_btnBorrarActionPerformed

    private void btnRefrescarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefrescarActionPerformed

        try {
            horas = Integer.parseInt(txtHoras.getText());
            horasExtra = Integer.parseInt(txtHorasEX.getText());

            sueldo = horas * precio;
            sueldoExtra = horasExtra * HoraExtra;
            total = sueldoExtra + sueldo;

            SuledoNormal.setText(String.valueOf(sueldo));
            SueldoExtras.setText(String.valueOf(sueldoExtra));
            Total.setText(String.valueOf(total));
            
            
            
            EmpleadosPago objeto1 = new EmpleadosPago();
            objeto1.setId(Integer.parseInt(txtId.getText()));
            objeto1.setNombre(txtNombre.getText());
            objeto1.setApellido(txtApellido.getText());
            objeto1.setPagoHoras(Integer.parseInt(SuledoNormal.getText()));
            objeto1.setPagoHorasExtras(Integer.parseInt(SueldoExtras.getText()));
            objeto1.setTotalPago(Integer.parseInt(Total.getText()));
            Personall.add(objeto1);
            JOptionPane.showMessageDialog(null, "Empleado agregado");

            tablaFinal();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "ERROR");
        }


    }//GEN-LAST:event_btnRefrescarActionPerformed

    private void tblTablaEmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTablaEmMouseClicked
        if (evt.getClickCount() == 1) {
            JTable receptor = (JTable) evt.getSource();

            txtId.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 0).toString());
            txtNombre.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 1).toString());
            txtApellido.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 2).toString());
            txtTelefono.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 3).toString());
            txtHoras.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 4).toString());
            txtHorasEX.setText(receptor.getModel().getValueAt(receptor.getSelectedRow(), 5).toString());
        }
    }//GEN-LAST:event_tblTablaEmMouseClicked

    private void txtHorasEXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHorasEXActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHorasEXActionPerformed

    public void Limpiar() {
        txtId.setText("");
        txtNombre.setText("");
        txtApellido.setText("");
        txtTelefono.setText("");
        txtHoras.setText("");
        txtHorasEX.setText("");

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Nomina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Nomina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Nomina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Nomina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Nomina().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel SueldoExtras;
    private javax.swing.JLabel SuledoNormal;
    private javax.swing.JLabel Total;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnRefrescar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable tblFinal;
    private javax.swing.JTable tblTablaEm;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtHoras;
    private javax.swing.JTextField txtHorasEX;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
