
package Nomina;


public class EmpleadosPago extends Empleados{
    
    public int numeroHoras;
    public int numeroHorasExtras;
    public int pagoHoras;
    public int pagoHorasExtras;
    public int totalPago;

    public EmpleadosPago(int numeroHoras, int numeroHorasExtras,int totalPago) {
        this.totalPago =totalPago;
        this.numeroHoras = numeroHoras;
        this.numeroHorasExtras = numeroHorasExtras;
    }
  
    public EmpleadosPago(int numeroHoras, int numeroHorasExtras, int id, String nombre, String apellido, String telefono,int totalPago) {
        super(id, nombre, apellido, telefono);
        this.totalPago =totalPago;
        this.numeroHoras = numeroHoras;
        this.numeroHorasExtras = numeroHorasExtras;
    }
    
    
    
    
    public EmpleadosPago() {
    }

    
    
    
    
    public int getNumeroHoras() {
        return numeroHoras;
    }

    public void setNumeroHoras(int numeroHoras) {
        this.numeroHoras = numeroHoras;
    }

    public int getNumeroHorasExtras() {
        return numeroHorasExtras;
    }

    public void setNumeroHorasExtras(int numeroHorasExtras) {
        this.numeroHorasExtras = numeroHorasExtras;
    }

    public int getTotalPago() {
        return totalPago;
    }

    public void setTotalPago(int totalPago) {
        this.totalPago = totalPago;
    }

    
    
    
    
    
    
    
    
    
    
    
    public EmpleadosPago(int numeroHoras, int numeroHorasExtras, int pagoHoras, int pagoHorasExtras) {
        this.numeroHoras = numeroHoras;
        this.numeroHorasExtras = numeroHorasExtras;
        this.pagoHoras = pagoHoras;
        this.pagoHorasExtras = pagoHorasExtras;
    }

    public EmpleadosPago(int numeroHoras, int numeroHorasExtras, int pagoHoras, int pagoHorasExtras, int id, String nombre, String apellido, String telefono) {
        super(id, nombre, apellido, telefono);
        this.numeroHoras = numeroHoras;
        this.numeroHorasExtras = numeroHorasExtras;
        this.pagoHoras = pagoHoras;
        this.pagoHorasExtras = pagoHorasExtras;
    }

    public int getPagoHoras() {
        return pagoHoras;
    }

    public void setPagoHoras(int pagoHoras) {
        this.pagoHoras = pagoHoras;
    }

    public int getPagoHorasExtras() {
        return pagoHorasExtras;
    }

    public void setPagoHorasExtras(int pagoHorasExtras) {
        this.pagoHorasExtras = pagoHorasExtras;
    }
    
    
    
    
    
    
    
}
