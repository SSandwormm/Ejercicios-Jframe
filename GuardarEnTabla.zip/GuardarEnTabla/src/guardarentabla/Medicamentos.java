
package guardarentabla;

public class Medicamentos {
    
     String tipo;
    String nombre ;
    String laboratorio;
    String componentes;
    double  precio;
    int stock ;
    
    public Medicamentos(){
    }

    public Medicamentos (String tipo, String nombre, String laboratorio, String componentes, double precio, int stock) {
        this.tipo = tipo;
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.componentes = componentes;
        this.precio = precio;
        this.stock = stock;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLaboratorio() {
        return laboratorio;
    }

    public void setLaboratorio(String laboratorio) {
        this.laboratorio = laboratorio;
    }

    public String getComponentes() {
        return componentes;
    }

    public void setComponentes(String componentes) {
        this.componentes = componentes;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Medicamento{" + "tipo=" + tipo + ", nombre=" + nombre + ", laboratorio=" + laboratorio + ", componentes=" + componentes + ", precio=" + precio + ", stock=" + stock + '}';
    }

   
}
