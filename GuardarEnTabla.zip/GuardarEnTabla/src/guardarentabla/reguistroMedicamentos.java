
package guardarentabla;

import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class reguistroMedicamentos extends javax.swing.JFrame {

    
     DefaultTableModel Modelo = new DefaultTableModel();
    ArrayList<Medicamentos> Listamedicamentos = new ArrayList<Medicamentos>();
    
    public reguistroMedicamentos() {
        initComponents();
        
        //imagenes y titulo
        this.setTitle("Guardar");
        Image img = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/recursos/guardarr.png/"));
        this.setIconImage(img);
        lblLogo.setIcon(new ImageIcon(img.getScaledInstance(lblLogo.getWidth(), lblLogo.getHeight(), Image.SCALE_SMOOTH)));
        
        //centrar
        this.setLocationRelativeTo(null);
        
        
        Modelo.addColumn("tipo");
        Modelo.addColumn("nombre");
        Modelo.addColumn("laboratorio");
        Modelo.addColumn("componenetes");
        Modelo.addColumn("precio");
        Modelo.addColumn("stock");
        refrescarTabla();
    }

  
    @SuppressWarnings("unchecked")
    
     public void refrescarTabla() {
        while (Modelo.getRowCount() > 0) {
            Modelo.removeRow(0);

        }

        for (Medicamentos Listamedicamento : Listamedicamentos) {
            Object a[] = new Object[6];
            a[0] = Listamedicamento.getTipo();
            a[1] = Listamedicamento.getNombre();
            a[2] = Listamedicamento.getLaboratorio();
            a[3] = Listamedicamento.getComponentes();
            a[4] = Listamedicamento.getPrecio();
            a[5] = Listamedicamento.getStock();
            Modelo.addRow(a);
        }

        tblRegistroMedicamentos.setModel(Modelo);

    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblTipo = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblLaboratorio = new javax.swing.JLabel();
        lblComponentes = new javax.swing.JLabel();
        lblPrecio = new javax.swing.JLabel();
        lblStock = new javax.swing.JLabel();
        txtTipoMedicina = new javax.swing.JTextField();
        txtNombreMedicina = new javax.swing.JTextField();
        txtLaboratorio = new javax.swing.JTextField();
        txtComponentes = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        txtStock = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        lblMade = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblRegistroMedicamentos = new javax.swing.JTable();
        lblLogo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTipo.setText("tipo :");
        jPanel1.add(lblTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 50, 30));

        lblNombre.setText("nombre :");
        jPanel1.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 130, 70, 30));

        lblLaboratorio.setText("laboratorio :");
        jPanel1.add(lblLaboratorio, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, 80, 30));

        lblComponentes.setText("componentes :");
        jPanel1.add(lblComponentes, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 90, 30));

        lblPrecio.setText("precio :");
        jPanel1.add(lblPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 250, 50, 30));

        lblStock.setText("stock :");
        jPanel1.add(lblStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, 50, 30));
        jPanel1.add(txtTipoMedicina, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, 110, 30));

        txtNombreMedicina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreMedicinaActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombreMedicina, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 90, 110, 30));

        txtLaboratorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLaboratorioActionPerformed(evt);
            }
        });
        jPanel1.add(txtLaboratorio, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 110, 30));
        jPanel1.add(txtComponentes, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 210, 110, 30));
        jPanel1.add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 110, 30));
        jPanel1.add(txtStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, 110, 30));

        btnAgregar.setText("agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        jPanel1.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 130, 100, 190));

        btnEliminar.setText("limpiar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 240, 110, 80));

        lblMade.setText("made : Sandworm");
        jPanel1.add(lblMade, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 560, 100, -1));

        lblTitulo.setFont(new java.awt.Font("Trebuchet MS", 2, 36)); // NOI18N
        lblTitulo.setText("Implementacion De Productos ");
        jPanel1.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 500, 50));

        tblRegistroMedicamentos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tblRegistroMedicamentos);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 580, 190));

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/guardarr.png"))); // NOI18N
        jPanel1.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 130, 100, 100));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 658, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreMedicinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreMedicinaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreMedicinaActionPerformed

    private void txtLaboratorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLaboratorioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLaboratorioActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        try {
            Medicamentos objeto = new Medicamentos();
            objeto.setTipo(txtTipoMedicina.getText());
            objeto.setNombre(txtNombreMedicina.getText());
            objeto.setLaboratorio(txtLaboratorio.getText());
            objeto.setComponentes(txtComponentes.getText());
            objeto.setPrecio(Double.parseDouble(txtPrecio.getText()));
            objeto.setStock(Integer.parseInt(txtStock.getText()));
            Listamedicamentos.add(objeto);
            refrescarTabla();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "ERROR");
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        txtTipoMedicina.setText("");
        txtNombreMedicina.setText("");
        txtLaboratorio.setText("");
        txtComponentes.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
    }//GEN-LAST:event_btnEliminarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reguistroMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(reguistroMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(reguistroMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(reguistroMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new reguistroMedicamentos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblComponentes;
    private javax.swing.JLabel lblLaboratorio;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblMade;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPrecio;
    private javax.swing.JLabel lblStock;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTable tblRegistroMedicamentos;
    private javax.swing.JTextField txtComponentes;
    private javax.swing.JTextField txtLaboratorio;
    private javax.swing.JTextField txtNombreMedicina;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtStock;
    private javax.swing.JTextField txtTipoMedicina;
    // End of variables declaration//GEN-END:variables
}
