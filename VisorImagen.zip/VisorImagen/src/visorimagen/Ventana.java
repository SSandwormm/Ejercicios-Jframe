
package visorimagen;

public class Ventana extends javax.swing.JFrame {

    javax.swing.ImageIcon[] img;
    int n;

    public Ventana() {
        
        initComponents();
        //Inicializar
        n=0;
        img = new javax.swing.ImageIcon[15];
        cargarImagenes();
        lblPantalla.setIcon(img[n]);
        
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        btnPrimero = new javax.swing.JButton();
        btnSiguiente = new javax.swing.JButton();
        btnUltimo = new javax.swing.JButton();
        Scroll = new javax.swing.JSpinner();
        lblPantalla = new javax.swing.JLabel();
        btnAnterior = new javax.swing.JButton();
        lblMade = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Visor de Imagenes");
        setResizable(false);

        Fondo.setBackground(new java.awt.Color(204, 255, 204));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnPrimero.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Elección/First record.png"))); // NOI18N
        btnPrimero.setText("Primera");
        btnPrimero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrimeroActionPerformed(evt);
            }
        });
        Fondo.add(btnPrimero, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, -1, -1));

        btnSiguiente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Elección/Go forward.png"))); // NOI18N
        btnSiguiente.setText("Siguiente");
        btnSiguiente.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnSiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSiguienteActionPerformed(evt);
            }
        });
        Fondo.add(btnSiguiente, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 370, -1, -1));

        btnUltimo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Elección/Last recor.png"))); // NOI18N
        btnUltimo.setText("Ultimo");
        btnUltimo.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnUltimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUltimoActionPerformed(evt);
            }
        });
        Fondo.add(btnUltimo, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 370, -1, -1));

        Scroll.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Scroll.setModel(new javax.swing.SpinnerNumberModel(0, 0, 14, 1));
        Scroll.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                ScrollStateChanged(evt);
            }
        });
        Fondo.add(Scroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 370, -1, -1));

        lblPantalla.setBorder(new javax.swing.border.MatteBorder(null));
        Fondo.add(lblPantalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 230, 250));

        btnAnterior.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Elección/Go back.png"))); // NOI18N
        btnAnterior.setText("Anterior");
        btnAnterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnteriorActionPerformed(evt);
            }
        });
        Fondo.add(btnAnterior, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 370, -1, -1));

        lblMade.setText("Made: Ssandwormm");
        Fondo.add(lblMade, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 430, 140, 20));

        lblTitulo.setFont(new java.awt.Font("Tw Cen MT", 3, 48)); // NOI18N
        lblTitulo.setText("iWormm");
        Fondo.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, 170, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Fondo, javax.swing.GroupLayout.PREFERRED_SIZE, 574, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ScrollStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_ScrollStateChanged
        //Segun el Valor del Spinner Cambiar a la Imagen correspondiente
        n = (int)Scroll.getValue();
        lblPantalla.setIcon(img[n]);
    }//GEN-LAST:event_ScrollStateChanged

    private void btnUltimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUltimoActionPerformed
        // TODO add your handling code here:
        n=14;
        Scroll.setValue(n);
    }//GEN-LAST:event_btnUltimoActionPerformed

    private void btnSiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSiguienteActionPerformed
        // cuando sea menor a 14:
        if(n<14){
            n++;
            Scroll.setValue(n);
        }else{
            //jSpinner1.setValue(n);
            getToolkit().beep(); // Emite Sonido de Error (campana)
        }
    }//GEN-LAST:event_btnSiguienteActionPerformed

    private void btnAnteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnteriorActionPerformed
        // Caundo sea mayor a 0:
        if(n>0){
            n--;
            Scroll.setValue(n);
        }else{
            //jSpinner1.setValue(n);
            getToolkit().beep(); // Emite Sonido de Error (campana)
        }
    }//GEN-LAST:event_btnAnteriorActionPerformed

    private void btnPrimeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrimeroActionPerformed
        // TODO add your handling code here:
        n=0;
        Scroll.setValue(n);
    }//GEN-LAST:event_btnPrimeroActionPerformed

    public void cargarImagenes(){
        //Añadir las imagenes a cada posicion del Arreglo
        img[0] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/0.png"));
        img[1] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/1.png"));
        img[2] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/2.png"));
        img[3] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/3.png"));
        img[4] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/4.png"));
        img[5] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/5.png"));
        img[6] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/6.png"));
        img[7] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/7.png"));
        img[8] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/8.png"));
        img[9] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/9.png"));
        img[10] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/10.png"));
        img[11] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/11.png"));
        img[12] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/12.png"));
        img[13] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/13.png"));
        img[14] = new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Grupo/14.png"));
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo;
    private javax.swing.JSpinner Scroll;
    private javax.swing.JButton btnAnterior;
    private javax.swing.JButton btnPrimero;
    private javax.swing.JButton btnSiguiente;
    private javax.swing.JButton btnUltimo;
    private javax.swing.JLabel lblMade;
    private javax.swing.JLabel lblPantalla;
    private javax.swing.JLabel lblTitulo;
    // End of variables declaration//GEN-END:variables
}
