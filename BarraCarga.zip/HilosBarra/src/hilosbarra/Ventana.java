
package hilosbarra;


public class Ventana extends javax.swing.JFrame {
    HilosBarra h1, h2;

    public Ventana() {
        initComponents();
        setLocationRelativeTo(null);
        cargaAutomatica();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblText1 = new javax.swing.JLabel();
        lblText2 = new javax.swing.JLabel();
        btnStart = new javax.swing.JButton();
        jProgressBar2 = new javax.swing.JProgressBar();
        btnStop = new javax.swing.JButton();
        jProgressBar1 = new javax.swing.JProgressBar();
        lblMade = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Ejemplo Hilos Barra de Progreso");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblText1.setFont(new java.awt.Font("Tw Cen MT", 3, 14)); // NOI18N
        lblText1.setText("Inicio por Acción del Usuario");
        jPanel1.add(lblText1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, -1, -1));

        lblText2.setFont(new java.awt.Font("Tw Cen MT", 3, 14)); // NOI18N
        lblText2.setText("Inicio Automático");
        jPanel1.add(lblText2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, -1, -1));

        btnStart.setFont(new java.awt.Font("Tw Cen MT", 3, 14)); // NOI18N
        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });
        jPanel1.add(btnStart, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, 90, 40));

        jProgressBar2.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 48)); // NOI18N
        jProgressBar2.setForeground(new java.awt.Color(0, 102, 204));
        jProgressBar2.setStringPainted(true);
        jPanel1.add(jProgressBar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, 270, -1));

        btnStop.setFont(new java.awt.Font("Tw Cen MT", 3, 14)); // NOI18N
        btnStop.setText("Stop");
        btnStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStopActionPerformed(evt);
            }
        });
        jPanel1.add(btnStop, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 310, 90, 40));

        jProgressBar1.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 48)); // NOI18N
        jProgressBar1.setForeground(new java.awt.Color(0, 153, 204));
        jProgressBar1.setValue(50);
        jProgressBar1.setIndeterminate(true);
        jProgressBar1.setStringPainted(true);
        jPanel1.add(jProgressBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 270, -1));

        lblMade.setText("Made : Ssandwormm");
        jPanel1.add(lblMade, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 410, 130, 20));

        lblTitulo.setFont(new java.awt.Font("Tw Cen MT", 3, 48)); // NOI18N
        lblTitulo.setText("loading...");
        jPanel1.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 20, 180, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        h2 = new HilosBarra(250);
        h2.recibejProgressBar1(jProgressBar2);
        h2.start();
    }//GEN-LAST:event_btnStartActionPerformed

    private void btnStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStopActionPerformed
        // TODO add your handling code here:
        h2.stop();
    }//GEN-LAST:event_btnStopActionPerformed

    public void cargaAutomatica(){
        h1 = new HilosBarra();
        h1.recibejProgressBar1(jProgressBar1);
        h1.start();
    }
    

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            javax.swing.UIManager.setLookAndFeel("com.jtattoo.plaf.acryl.AcrylLookAndFeel");
                    
            /*for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }*/
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnStop;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JProgressBar jProgressBar2;
    private javax.swing.JLabel lblMade;
    private javax.swing.JLabel lblText1;
    private javax.swing.JLabel lblText2;
    private javax.swing.JLabel lblTitulo;
    // End of variables declaration//GEN-END:variables
}
