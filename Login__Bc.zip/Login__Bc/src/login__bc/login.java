package login__bc;


import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class login extends javax.swing.JFrame {

    public login() {
        initComponents();
        
         //imagenes y titulo
        this.setTitle("LOGIN");
        Image img = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Recursos/usuarioo.png/"));
        this.setIconImage(img);
        lblLogo.setIcon(new ImageIcon(img.getScaledInstance(lblLogo.getWidth(), lblLogo.getHeight(), Image.SCALE_SMOOTH)));
        
        //centrar
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        FondoPrincipal = new javax.swing.JPanel();
        Fondo2 = new javax.swing.JPanel();
        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        lblPass = new javax.swing.JLabel();
        txtPass = new javax.swing.JPasswordField();
        btnIngresar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        lblTitulo = new javax.swing.JLabel();
        Separator = new javax.swing.JSeparator();
        panelIcon = new javax.swing.JPanel();
        lblminilogo = new javax.swing.JLabel();
        panelIcon1 = new javax.swing.JPanel();
        lblminilogo1 = new javax.swing.JLabel();
        Fondo1 = new javax.swing.JPanel();
        lblLogo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        FondoPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo2.setBackground(new java.awt.Color(204, 255, 204));
        Fondo2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUsuario.setFont(new java.awt.Font("Trebuchet MS", 2, 12)); // NOI18N
        lblUsuario.setText("Usuario :");
        Fondo2.add(lblUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 70, 40));
        Fondo2.add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 200, 40));

        lblPass.setFont(new java.awt.Font("Trebuchet MS", 2, 12)); // NOI18N
        lblPass.setText("Password :");
        Fondo2.add(lblPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, 70, 40));
        Fondo2.add(txtPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 280, 200, 40));

        btnIngresar.setText("Ingresar");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });
        Fondo2.add(btnIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, 240, 40));

        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        Fondo2.add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 390, 240, 40));

        lblTitulo.setFont(new java.awt.Font("Century Gothic", 3, 48)); // NOI18N
        lblTitulo.setText("LOGIN");
        Fondo2.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 180, 40));
        Fondo2.add(Separator, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 370, 20));

        panelIcon.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblminilogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/usuario.png"))); // NOI18N
        panelIcon.add(lblminilogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 30, 40));

        Fondo2.add(panelIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 40, 40));

        panelIcon1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblminilogo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/llave.png"))); // NOI18N
        panelIcon1.add(lblminilogo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 30, 40));

        Fondo2.add(panelIcon1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 280, 40, 40));

        FondoPrincipal.add(Fondo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 448, 540));

        Fondo1.setBackground(new java.awt.Color(153, 255, 153));
        Fondo1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/usuarioo.png"))); // NOI18N
        Fondo1.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 240, 230));
        Fondo1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 340, 30));

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 2, 14)); // NOI18N
        jLabel1.setText("Los mejores expertos para obtener los mejores datos");
        Fondo1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 370, 30));

        FondoPrincipal.add(Fondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 540));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(FondoPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(FondoPrincipal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        String usuario = txtUsuario.getText();
        String paswd = txtPass.getText();

        if (usuario.isEmpty() || paswd.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Algún campo esta vacio");

        } else {
            if (usuario.equals("admin") && paswd.equals("admin")) {
                JOptionPane.showMessageDialog(null, "Bienvenido");
                panel_control pc = new panel_control();
                pc.setVisible(true);
                this.dispose();

            } else {

                JOptionPane.showMessageDialog(null, "Su usuario o contraseña es incorrecto");

            }
        }
    }//GEN-LAST:event_btnIngresarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo1;
    private javax.swing.JPanel Fondo2;
    private javax.swing.JPanel FondoPrincipal;
    private javax.swing.JSeparator Separator;
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblPass;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JLabel lblminilogo;
    private javax.swing.JLabel lblminilogo1;
    private javax.swing.JPanel panelIcon;
    private javax.swing.JPanel panelIcon1;
    private javax.swing.JPasswordField txtPass;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
