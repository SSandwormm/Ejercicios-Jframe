
package cambio;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

public class cambio extends javax.swing.JFrame {

  
    DefaultTableModel modelo;
    public cambio() {
        
        initComponents();
        modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido");
        tabla1.setModel (modelo);
       
        Cambio2 tabla2 = new Cambio2();
        tabla2.setVisible(true);
        
        
        
         //imagenes y titulo
        this.setTitle("Cambio de Datos");
        Image img = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Recursos/Cambio.png/"));
        this.setIconImage(img);
        lblLogo.setIcon(new ImageIcon(img.getScaledInstance(lblLogo.getWidth(), lblLogo.getHeight(), Image.SCALE_SMOOTH)));
        
        //centrar
        this.setLocationRelativeTo(null);
        
    }

    public void nuevatabla(){
    modelo =new DefaultTableModel();
    tabla1.setModel(modelo);
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnSeleccionar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        lblLogo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Fondo.setBackground(new java.awt.Color(204, 255, 204));
        Fondo.setPreferredSize(new java.awt.Dimension(400, 501));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabla1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabla1);

        Fondo.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 530, 190));

        jLabel1.setText("Nombre :");
        Fondo.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 60, 40));

        jLabel2.setText("Apellido :");
        Fondo.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 60, 40));
        Fondo.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 140, 40));
        Fondo.add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, 140, 40));

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        Fondo.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 110, 160));

        btnSeleccionar.setText("Pasar una Fila ");
        btnSeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeleccionarActionPerformed(evt);
            }
        });
        Fondo.add(btnSeleccionar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 500, 200, 50));

        jButton1.setText("Pasar Todo");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        Fondo.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 500, 180, 50));

        jLabel3.setText("Made : SSandwormm");
        Fondo.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 590, 130, 20));

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/Cambio.png"))); // NOI18N
        Fondo.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, 110, 110));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Fondo, javax.swing.GroupLayout.PREFERRED_SIZE, 602, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Fondo, javax.swing.GroupLayout.PREFERRED_SIZE, 622, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeleccionarActionPerformed
        int FilaSelecionada=tabla1.getSelectedRow();
        
        if (FilaSelecionada>=0) {
            String Datos []= new String [2];
            Datos[0] = tabla1.getValueAt(FilaSelecionada,0).toString();
            Datos[1] = tabla1.getValueAt(FilaSelecionada,1).toString();   
            
            Cambio2.modelo2.addRow(Datos);
            modelo.removeRow(FilaSelecionada);
        }
    }//GEN-LAST:event_btnSeleccionarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        String Nombre = txtNombre.getText();
        String Apellido = txtApellido.getText();
        String Datos []= {Nombre,Apellido};
        modelo.addRow(Datos);
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          for (int i = 0; i < tabla1.getRowCount(); i++) {
            String Datos []= new String [2];
            Datos [0] = tabla1.getValueAt(i,0). toString();
            Datos [1] = tabla1.getValueAt(i,1). toString();
            
            Cambio2.modelo2.addRow(Datos);
           
        }
        nuevatabla();
    }//GEN-LAST:event_jButton1ActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(cambio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(cambio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(cambio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(cambio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new cambio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnSeleccionar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JTable tabla1;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
