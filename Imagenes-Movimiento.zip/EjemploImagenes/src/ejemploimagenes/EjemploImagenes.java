
package ejemploimagenes;

/**
 *
 * @author Global Tech
 */
public class EjemploImagenes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        VentanaPrincipal.main(args);
    }
    
}
